import { Link } from "react-router-dom";
import { CheckCircle2 } from "lucide-react";
import { Button } from "../../components/ui/core";

export default function BookingSuccess() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="max-w-md w-full text-center space-y-8 bg-white p-10 rounded-3xl shadow-xl">
        <div className="mx-auto flex items-center justify-center h-24 w-24 rounded-full bg-green-100">
          <CheckCircle2 className="h-12 w-12 text-green-600" />
        </div>
        <div className="space-y-3">
          <h2 className="text-3xl font-extrabold text-gray-900 tracking-tight">Booking Berhasil!</h2>
          <p className="text-gray-500 text-lg">
            Terima kasih, booking servis mobil Anda sudah kami terima. Admin bengkel akan segera menghubungi Anda melalui WhatsApp untuk konfirmasi.
          </p>
        </div>
        <div className="pt-6">
          <Link to="/">
            <Button variant="outline" className="w-full">
              Kembali ke Halaman Utama
            </Button>
          </Link>
        </div>
        <div className="mt-4 text-center">
          <Link to="/admin" className="text-sm text-gray-400 hover:text-gray-600">
            Owner Login
          </Link>
        </div>
      </div>
    </div>
  );
}
