import React, { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { format } from "date-fns";
import { Card, CardContent, CardHeader, CardTitle, Input, Label, Select, Textarea, Button } from "../../components/ui/core";
import { Calendar, Clock, Wrench } from "lucide-react";

export default function BookingForm() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [settings, setSettings] = useState<any>(null);
  const [services, setServices] = useState<any[]>([]);
  const [date, setDate] = useState<string>(format(new Date(), "yyyy-MM-dd"));
  const [availableSlots, setAvailableSlots] = useState<any[]>([]);

  useEffect(() => {
    fetch("/api/settings/public").then(res => res.json()).then(setSettings);
    fetch("/api/services/public").then(res => res.json()).then(data => setServices(Array.isArray(data) ? data : []));
  }, []);

  useEffect(() => {
    if (date && settings) {
      fetch(`/api/slots?date=${date}`).then(res => res.json()).then(data => {
        // Generate slots
        const slots = [];
        const start = parseInt(data.settings.openTime.split(":")[0]);
        const end = parseInt(data.settings.closeTime.split(":")[0]);
        const interval = data.settings.slotIntervalMinutes;
        
        for (let i = start; i < end; i += (interval/60)) {
          const timeString = `${String(Math.floor(i)).padStart(2, '0')}:${String((i % 1) * 60).padStart(2, '0')}`;
          const bookedCount = data.bookings.find((b: any) => b.time === timeString)?.count || 0;
          slots.push({
            time: timeString,
            isFull: bookedCount >= data.settings.maxBookingPerSlot,
            available: data.settings.maxBookingPerSlot - bookedCount
          });
        }
        setAvailableSlots(slots);
      });
    }
  }, [date, settings]);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);
    const fd = new FormData(e.currentTarget);
    const data = Object.fromEntries(fd.entries());
    
    try {
      const res = await fetch("/api/bookings/public", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (res.ok) {
        navigate("/booking/success");
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (!settings) return <div className="min-h-screen flex items-center justify-center bg-gray-50 text-gray-500">Memuat...</div>;

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="max-w-xl mx-auto">
        <div className="text-center mb-10">
          <h1 className="text-3xl font-extrabold tracking-tight text-gray-900 sm:text-4xl">
            {settings.workshopName}
          </h1>
          <p className="mt-4 text-lg text-gray-500">
            Booking servis mobil Anda dengan cepat dan mudah.
          </p>
        </div>

        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Form Booking Servis</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="customerName">Nama Lengkap *</Label>
                  <Input id="customerName" name="customerName" required placeholder="Budi Santoso" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="customerPhone">No. WhatsApp *</Label>
                  <Input id="customerPhone" name="customerPhone" required placeholder="08123456789" type="tel" />
                </div>
              </div>

              <div className="space-y-4 rounded-xl border border-gray-100 bg-gray-50/50 p-4">
                <h4 className="font-medium flex items-center gap-2 text-gray-700">
                  <Calendar className="w-4 h-4" /> Jadwal Kedatangan
                </h4>
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="bookingDate">Tanggal *</Label>
                    <Input 
                      id="bookingDate" 
                      name="bookingDate" 
                      type="date" 
                      required 
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      min={format(new Date(), "yyyy-MM-dd")}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="bookingTime">Jam (Slot) *</Label>
                    <Select id="bookingTime" name="bookingTime" required defaultValue="">
                      <option value="" disabled>Pilih jam kedatangan</option>
                      {availableSlots.map(slot => (
                        <option key={slot.time} value={slot.time} disabled={slot.isFull}>
                          {slot.time} {slot.isFull ? "(Penuh)" : `(${slot.available} slot tersedia)`}
                        </option>
                      ))}
                    </Select>
                  </div>
                </div>
              </div>

              <div className="space-y-4 rounded-xl border border-gray-100 bg-gray-50/50 p-4">
                <h4 className="font-medium flex items-center gap-2 text-gray-700">
                  <Wrench className="w-4 h-4" /> Data Kendaraan
                </h4>
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="carType">Tipe Mobil *</Label>
                    <Input id="carType" name="carType" required placeholder="Honda Brio" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="plateNumber">Plat Nomor</Label>
                    <Input id="plateNumber" name="plateNumber" placeholder="B 1234 XYZ" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="carYear">Tahun Mobil</Label>
                    <Input id="carYear" name="carYear" type="number" placeholder="2021" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="serviceType">Jenis Layanan *</Label>
                    <Select id="serviceType" name="serviceType" required defaultValue="">
                      <option value="" disabled>Pilih layanan</option>
                      {services.map(s => (
                        <option key={s.id} value={s.name}>{s.name}</option>
                      ))}
                    </Select>
                  </div>
                </div>
                <div className="space-y-2 mt-4">
                  <Label htmlFor="problemDescription">Keluhan / Problem *</Label>
                  <Textarea id="problemDescription" name="problemDescription" required placeholder="Contoh: AC kurang dingin, ada bunyi di bagian bawah" />
                </div>
              </div>

              <Button type="submit" className="w-full" size="lg" isLoading={loading}>
                Kirim Booking
              </Button>
            </form>
          </CardContent>
        </Card>
        
        <div className="mt-8 text-center">
          <Link to="/admin" className="text-sm text-gray-400 hover:text-gray-600">
            Owner Login
          </Link>
        </div>
      </div>
    </div>
  );
}
