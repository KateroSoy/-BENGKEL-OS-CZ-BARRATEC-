import { Outlet, Link, useLocation, useNavigate } from "react-router-dom";
import { LayoutDashboard, Calendar as CalendarIcon, Users, Settings, LogOut, Wrench, FileText, PlusCircle, BarChart } from "lucide-react";
import { cn } from "../../lib/utils";

const navigation = [
  { name: 'Dashboard', href: '/admin/dashboard', icon: LayoutDashboard },
  { name: 'Booking Hari Ini', href: '/admin/bookings/today', icon: FileText },
  { name: 'Kalender Booking', href: '/admin/calendar', icon: CalendarIcon },
  { name: 'Tambah Booking', href: '/admin/bookings/new', icon: PlusCircle },
  { name: 'Layanan & Teknisi', href: '/admin/services', icon: Users },
  { name: 'Laporan', href: '/admin/reports', icon: BarChart },
  { name: 'Pengaturan', href: '/admin/settings', icon: Settings },
];

export default function AdminLayout() {
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' });
    navigate('/admin/login');
  };

  return (
    <div className="flex h-screen print:h-auto bg-gray-50 font-sans print:bg-white">
      {/* Sidebar - Desktop */}
      <div className="hidden md:flex md:w-72 md:flex-col border-r border-gray-200 bg-white print:hidden">
        <div className="flex flex-col flex-grow pt-8 pb-4 overflow-y-auto">
          <div className="flex items-center flex-shrink-0 px-6 mb-8">
            <Wrench className="h-8 w-8 text-blue-600" />
            <span className="ml-3 text-xl font-bold tracking-tight text-gray-900">BENGKEL OS</span>
          </div>
          <nav className="mt-2 flex-1 px-4 space-y-1">
            {navigation.map((item) => {
              const isActive = location.pathname.startsWith(item.href);
              return (
                <Link
                  key={item.name}
                  to={item.href}
                  className={cn(
                    isActive ? 'bg-blue-50 text-blue-700 font-semibold' : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900',
                    'group flex items-center px-4 py-3 text-sm rounded-xl transition-colors'
                  )}
                >
                  <item.icon
                    className={cn(
                      isActive ? 'text-blue-700' : 'text-gray-400 group-hover:text-gray-500',
                      'mr-3 flex-shrink-0 h-5 w-5'
                    )}
                    aria-hidden="true"
                  />
                  {item.name}
                </Link>
              );
            })}
          </nav>
        </div>
        <div className="flex-shrink-0 flex border-t border-gray-200 p-4">
          <button
            onClick={handleLogout}
            className="flex-shrink-0 w-full group block text-gray-600 hover:text-red-600 transition-colors"
          >
            <div className="flex items-center px-4 py-3 text-sm font-medium">
              <LogOut className="mr-3 h-5 w-5 text-gray-400 group-hover:text-red-500" />
              Keluar
            </div>
          </button>
        </div>
      </div>

      {/* Main content */}
      <div className="flex flex-col w-0 flex-1 overflow-hidden print:overflow-visible">
        <main className="flex-1 relative z-0 overflow-y-auto focus:outline-none pb-20 md:pb-0 print:overflow-visible">
          <div className="py-6 px-4 sm:px-6 md:px-8 max-w-7xl mx-auto print:p-0 print:max-w-none">
            <Outlet />
          </div>
        </main>
      </div>

      {/* Bottom Nav - Mobile */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-gray-200 safe-area-pb print:hidden">
        <div className="flex justify-around">
          {navigation.slice(0, 4).map((item) => {
            const isActive = location.pathname === item.href;
            return (
              <Link
                key={item.name}
                to={item.href}
                className={cn(
                  "flex flex-col items-center py-3 px-2 text-xs font-medium transition-colors",
                  isActive ? "text-blue-600" : "text-gray-500 hover:text-gray-900"
                )}
              >
                <item.icon className={cn("h-6 w-6 mb-1", isActive ? "text-blue-600" : "text-gray-400")} />
                <span className="truncate">{item.name.split(' ')[0]}</span>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}
