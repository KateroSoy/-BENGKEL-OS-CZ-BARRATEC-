import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, Button, Input, Label } from "../../components/ui/core";
import { Save } from "lucide-react";

export default function Settings() {
  const [settings, setSettings] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch("/api/settings")
      .then(res => res.json())
      .then(data => {
        setSettings(data);
        setLoading(false);
      });
  }, []);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSaving(true);
    const fd = new FormData(e.currentTarget);
    const data = Object.fromEntries(fd.entries()) as any;
    
    // Convert numeric fields
    data.maxBookingPerSlot = Number(data.maxBookingPerSlot);
    data.slotIntervalMinutes = Number(data.slotIntervalMinutes);

    await fetch("/api/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });
    
    alert("Pengaturan berhasil disimpan.");
    setSaving(false);
  };

  if (loading) return <div className="text-gray-500">Memuat pengaturan...</div>;

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-10">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Pengaturan Bengkel</h1>
        <p className="text-gray-500 mt-1">Kelola profil dan konfigurasi booking</p>
      </div>

      <form onSubmit={handleSubmit}>
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Profil Bengkel</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="workshopName">Nama Bengkel</Label>
                <Input id="workshopName" name="workshopName" defaultValue={settings?.workshopName} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Nomor Telepon / WA</Label>
                <Input id="phone" name="phone" defaultValue={settings?.phone} required />
              </div>
              <div className="col-span-2 space-y-2">
                <Label htmlFor="address">Alamat Lengkap</Label>
                <Input id="address" name="address" defaultValue={settings?.address} required />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Operasional & Kapasitas</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="openTime">Jam Buka (HH:MM)</Label>
                <Input id="openTime" name="openTime" type="time" defaultValue={settings?.openTime} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="closeTime">Jam Tutup (HH:MM)</Label>
                <Input id="closeTime" name="closeTime" type="time" defaultValue={settings?.closeTime} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="slotIntervalMinutes">Interval Booking (Menit)</Label>
                <Input id="slotIntervalMinutes" name="slotIntervalMinutes" type="number" defaultValue={settings?.slotIntervalMinutes} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="maxBookingPerSlot">Maksimal Mobil Per Slot</Label>
                <Input id="maxBookingPerSlot" name="maxBookingPerSlot" type="number" defaultValue={settings?.maxBookingPerSlot} required />
              </div>
            </div>
          </CardContent>
        </Card>

        <Button type="submit" isLoading={saving} className="flex gap-2">
          <Save className="h-4 w-4" /> Simpan Pengaturan
        </Button>
      </form>
    </div>
  );
}
