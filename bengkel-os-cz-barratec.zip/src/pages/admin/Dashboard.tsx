import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle, Button } from "../../components/ui/core";
import { Calendar, CheckCircle2, Clock, FileText, PlusCircle, TrendingUp, XCircle, Wrench } from "lucide-react";

export default function Dashboard() {
  const [stats, setStats] = useState<any>(null);

  useEffect(() => {
    fetch("/api/dashboard/stats").then(res => res.json()).then(setStats);
  }, []);

  const getStatusCount = (statusName: string) => {
    if (!stats || !stats.statuses) return 0;
    const s = stats.statuses.find((x: any) => x.status === statusName);
    return s ? s.count : 0;
  };

  if (!stats) return <div className="text-gray-500">Memuat dashboard...</div>;

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-500 mt-1">Ringkasan operasional bengkel hari ini</p>
        </div>
        <div className="flex gap-2 w-full sm:w-auto">
          <Link to="/admin/bookings/new" className="flex-1 sm:flex-none">
            <Button className="w-full">
              <PlusCircle className="mr-2 h-4 w-4" /> Tambah Booking
            </Button>
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <div className="p-3 bg-blue-100 text-blue-600 rounded-xl">
                <FileText className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Total Hari Ini</p>
                <h3 className="text-2xl font-bold text-gray-900">{stats.todayTotal}</h3>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <div className="p-3 bg-amber-100 text-amber-600 rounded-xl">
                <Clock className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Menunggu</p>
                <h3 className="text-2xl font-bold text-gray-900">
                  {getStatusCount("Baru") + getStatusCount("Menunggu Konfirmasi")}
                </h3>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <div className="p-3 bg-orange-100 text-orange-600 rounded-xl">
                <Wrench className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Dikerjakan</p>
                <h3 className="text-2xl font-bold text-gray-900">{getStatusCount("Sedang Dikerjakan")}</h3>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <div className="p-3 bg-green-100 text-green-600 rounded-xl">
                <CheckCircle2 className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Selesai</p>
                <h3 className="text-2xl font-bold text-gray-900">{getStatusCount("Selesai")}</h3>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Aksi Cepat</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-2 gap-4">
            <Link to="/admin/bookings/today">
              <Button variant="outline" className="w-full h-24 flex-col gap-2">
                <Calendar className="h-6 w-6 text-blue-600" />
                <span>Lihat Jadwal</span>
              </Button>
            </Link>
            <Link to="/admin/services">
              <Button variant="outline" className="w-full h-24 flex-col gap-2">
                <Wrench className="h-6 w-6 text-gray-600" />
                <span>Kelola Layanan</span>
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
