import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, Button, Input, Label } from "../../components/ui/core";

export default function Services() {
  const [services, setServices] = useState<any[]>([]);
  const [technicians, setTechnicians] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setLoading(true);
    Promise.all([
      fetch("/api/services").then(res => res.json()),
      fetch("/api/technicians").then(res => res.json())
    ]).then(([s, t]) => {
      setServices(Array.isArray(s) ? s : []);
      setTechnicians(Array.isArray(t) ? t : []);
      setLoading(false);
    });
  };

  const handleAddService = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    await fetch("/api/services", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(Object.fromEntries(fd.entries()))
    });
    e.currentTarget.reset();
    loadData();
  };

  const handleAddTech = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    await fetch("/api/technicians", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(Object.fromEntries(fd.entries()))
    });
    e.currentTarget.reset();
    loadData();
  };

  if (loading) return <div className="text-gray-500">Memuat data...</div>;

  return (
    <div className="space-y-6 max-w-6xl mx-auto pb-10">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Layanan & Teknisi</h1>
        <p className="text-gray-500 mt-1">Kelola master data bengkel</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Services */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Tambah Layanan</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleAddService} className="space-y-4">
                <div>
                  <Label>Nama Layanan</Label>
                  <Input name="name" required />
                </div>
                <Button type="submit">Simpan Layanan</Button>
              </form>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Daftar Layanan</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {services.map(s => (
                  <div key={s.id} className="p-3 bg-gray-50 rounded-xl border border-gray-100 flex justify-between items-center">
                    <span className="font-medium text-gray-900">{s.name}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Technicians */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Tambah Teknisi</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleAddTech} className="space-y-4">
                <div>
                  <Label>Nama Teknisi</Label>
                  <Input name="name" required />
                </div>
                <div>
                  <Label>Spesialisasi</Label>
                  <Input name="specialty" />
                </div>
                <Button type="submit">Simpan Teknisi</Button>
              </form>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Daftar Teknisi</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {technicians.map(t => (
                  <div key={t.id} className="p-3 bg-gray-50 rounded-xl border border-gray-100 flex justify-between items-center">
                    <div>
                      <span className="font-medium text-gray-900 block">{t.name}</span>
                      <span className="text-xs text-gray-500">{t.specialty}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
