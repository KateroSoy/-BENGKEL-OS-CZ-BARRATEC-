import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { format } from "date-fns";
import { Card, CardContent, Button, StatusBadge, Input, Select } from "../../components/ui/core";
import { Search, MessageCircle, Calendar } from "lucide-react";
import { createWhatsAppLink } from "../../lib/utils";
import { WhatsAppHelper } from "../../utils/whatsapp";

export default function BookingsToday() {
  const [bookings, setBookings] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [services, setServices] = useState<any[]>([]);
  const [technicians, setTechnicians] = useState<any[]>([]);
  
  // Filters
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [serviceFilter, setServiceFilter] = useState("");
  const [techFilter, setTechFilter] = useState("");

  useEffect(() => {
    loadBookings();
    fetch("/api/services").then(res => res.json()).then(data => setServices(Array.isArray(data) ? data : []));
    fetch("/api/technicians").then(res => res.json()).then(data => setTechnicians(Array.isArray(data) ? data : []));
  }, []);

  // Debounced search effect
  useEffect(() => {
    const timer = setTimeout(() => {
      loadBookings();
    }, 500);
    return () => clearTimeout(timer);
  }, [search, statusFilter, serviceFilter, techFilter]);

  const loadBookings = () => {
    setLoading(true);
    const today = format(new Date(), "yyyy-MM-dd");
    let url = `/api/bookings?date=${today}`;
    if (search) url += `&search=${encodeURIComponent(search)}`;
    if (statusFilter) url += `&status=${encodeURIComponent(statusFilter)}`;
    if (serviceFilter) url += `&serviceType=${encodeURIComponent(serviceFilter)}`;
    if (techFilter) url += `&technicianId=${encodeURIComponent(techFilter)}`;

    fetch(url)
      .then(res => res.json())
      .then(data => {
        setBookings(Array.isArray(data) ? data : []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  };

  const handleWA = (phone: string, name: string, carType: string) => {
    const msg = `Halo Kak ${name}, dari BENGKEL OS. Mengenai booking servis mobil ${carType} Anda...`;
    window.open(createWhatsAppLink(phone, msg), "_blank");
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Booking Hari Ini</h1>
          <p className="text-gray-500 mt-1">{format(new Date(), "dd MMMM yyyy")}</p>
        </div>
      </div>

      <Card>
        <CardContent className="pt-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input 
              placeholder="Cari nama, hp, plat..." 
              className="pl-9" 
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>
          <Select value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
            <option value="">Semua Status</option>
            <option value="Baru">Baru</option>
            <option value="Menunggu Konfirmasi">Menunggu Konfirmasi</option>
            <option value="Terkonfirmasi">Terkonfirmasi</option>
            <option value="Datang">Datang</option>
            <option value="Sedang Dikerjakan">Sedang Dikerjakan</option>
            <option value="Selesai">Selesai</option>
          </Select>
          <Select value={serviceFilter} onChange={e => setServiceFilter(e.target.value)}>
            <option value="">Semua Layanan</option>
            {services.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}
          </Select>
          <Select value={techFilter} onChange={e => setTechFilter(e.target.value)}>
            <option value="">Semua Teknisi</option>
            {technicians.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
          </Select>
        </CardContent>
      </Card>

      {loading ? (
        <div className="text-gray-500 text-center py-10">Memuat data booking...</div>
      ) : bookings.length === 0 ? (
        <Card className="text-center py-16">
          <CardContent className="flex flex-col items-center">
            <div className="bg-gray-100 p-4 rounded-full mb-4">
              <Calendar className="h-8 w-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-medium text-gray-900">Belum ada booking hari ini</h3>
            <p className="text-gray-500 mt-1 max-w-sm">Booking dari form online, WhatsApp, telepon, dan walk-in akan muncul di sini.</p>
            <Link to="/admin/bookings/new" className="mt-6">
              <Button>Tambah Booking Manual</Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {bookings.map(b => (
            <Card key={b.id} className="hover:border-blue-200 transition-colors">
              <CardContent className="p-5">
                <div className="flex justify-between items-start mb-3">
                  <StatusBadge status={b.status} />
                  <div className="text-sm font-bold text-gray-900 bg-gray-100 px-2 py-1 rounded-md">
                    {b.bookingTime}
                  </div>
                </div>
                
                <h3 className="font-bold text-lg text-gray-900 truncate">{b.customerName}</h3>
                <p className="text-sm text-gray-500 mb-3">{b.carType} {b.plateNumber ? `• ${b.plateNumber}` : ''}</p>
                
                <div className="bg-gray-50 rounded-lg p-3 text-sm text-gray-700 mb-4 line-clamp-2">
                  <span className="font-medium">Keluhan:</span> {b.problemDescription}
                </div>

                <div className="flex items-center gap-2 mt-4 pt-4 border-t border-gray-100">
                  <Link to={`/admin/bookings/${b.id}`} className="flex-1">
                    <Button variant="outline" className="w-full text-sm h-9">Detail</Button>
                  </Link>
                  <Button 
                    variant="default" 
                    size="icon" 
                    className="h-9 w-9 bg-emerald-500 hover:bg-emerald-600 shrink-0"
                    onClick={() => handleWA(b.customerPhone, b.customerName, b.carType)}
                  >
                    <MessageCircle className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
