import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { format } from "date-fns";
import { Card, CardContent, CardHeader, CardTitle, Button, StatusBadge, Select, Input } from "../../components/ui/core";
import { ArrowLeft, MessageCircle, Clock, User, Wrench, FileText } from "lucide-react";
import { createWhatsAppLink } from "../../lib/utils";
import { WhatsAppHelper } from "../../utils/whatsapp";

const statuses = [
  "Baru", "Menunggu Konfirmasi", "Terkonfirmasi", "Datang", 
  "Sedang Dikerjakan", "Menunggu Sparepart", "Selesai", "Batal", "Tidak Datang"
];

function StatusHistoryTimeline({ history }: { history: any[] }) {
  if (!history || history.length === 0) {
    return <p className="text-gray-500 text-sm">Belum ada riwayat status.</p>;
  }
  return (
    <div className="space-y-4">
      {history.map((h: any, index: number) => (
        <div key={h.id} className="flex gap-4">
          <div className="w-24 sm:w-32 text-xs text-gray-500 shrink-0 text-right pt-0.5">
            {format(new Date(h.changedAt), "dd MMM yyyy")}
            <br className="hidden sm:block" />
            <span className="sm:hidden"> </span>
            {format(new Date(h.changedAt), "HH:mm")}
          </div>
          <div className={`border-l-2 ${index === history.length - 1 ? 'border-transparent' : 'border-blue-100'} pl-4 pb-4 relative flex-1`}>
            <div className="absolute w-2.5 h-2.5 bg-blue-500 rounded-full -left-[6px] top-1 ring-4 ring-white"></div>
            <p className="text-sm font-semibold text-gray-900">{h.newStatus}</p>
            {h.note && <p className="text-sm text-gray-600 mt-1">{h.note}</p>}
            <p className="text-xs text-gray-400 mt-1">Oleh: {h.adminName || "Sistem"}</p>
          </div>
        </div>
      ))}
    </div>
  );
}

export default function BookingDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [booking, setBooking] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [technicians, setTechnicians] = useState<any[]>([]);

  useEffect(() => {
    loadBooking();
    fetch("/api/technicians").then(res => res.json()).then(data => setTechnicians(Array.isArray(data) ? data : []));
  }, [id]);

  const loadBooking = () => {
    setLoading(true);
    fetch(`/api/bookings/${id}`)
      .then(res => res.json())
      .then(data => {
        setBooking(data);
        setLoading(false);
      });
  };

  const updateStatus = async (newStatus: string) => {
    const note = prompt("Catatan (opsional):");
    if (note !== null) {
      await fetch(`/api/bookings/${id}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus, note })
      });
      loadBooking();
    }
  };

  const updateTechnician = async (technicianId: string) => {
    await fetch(`/api/bookings/${id}/technician`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ technicianId })
    });
    loadBooking();
  };

  const handleWA = (type: string) => {
    let msg = "";
    const b = booking;
    if (type === "confirm") {
      msg = WhatsAppHelper.bookingConfirmed(b.customerName, b.carType, b.bookingDate, b.bookingTime);
    } else if (type === "done") {
      msg = WhatsAppHelper.vehicleDone(b.customerName, b.carType, b.plateNumber);
    } else if (type === "reminder") {
      msg = WhatsAppHelper.reminderH1(b.customerName, b.carType, b.bookingTime);
    } else if (type === "invoice") {
      const estimate = prompt("Masukkan estimasi harga:", b.estimatedPrice || "");
      if (estimate) {
        msg = WhatsAppHelper.estimateInvoice(b.customerName, b.carType, estimate, b.serviceType);
      } else {
        return; // Cancelled
      }
    } else {
      msg = `Halo Kak ${b.customerName}, dari BENGKEL OS.`;
    }
    window.open(createWhatsAppLink(b.customerPhone, msg), "_blank");
  };

  if (loading) return <div className="text-gray-500">Memuat detail...</div>;
  if (!booking || booking.error) return <div className="text-red-500">Booking tidak ditemukan</div>;

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-10">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Detail Booking</h1>
          <p className="text-gray-500 text-sm mt-1">{booking.bookingCode}</p>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <StatusBadge status={booking.status} />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
          <Card>
            <CardHeader className="border-b border-gray-100 pb-4">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Wrench className="h-5 w-5 text-gray-400" /> Data Kendaraan & Keluhan
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4 grid grid-cols-2 gap-y-4">
              <div>
                <p className="text-sm text-gray-500">Mobil</p>
                <p className="font-medium text-gray-900">{booking.carType} {booking.carYear ? `(${booking.carYear})` : ''}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Plat Nomor</p>
                <p className="font-medium text-gray-900">{booking.plateNumber || "-"}</p>
              </div>
              <div className="col-span-2">
                <p className="text-sm text-gray-500">Layanan</p>
                <p className="font-medium text-gray-900">{booking.serviceType}</p>
              </div>
              <div className="col-span-2 bg-gray-50 p-4 rounded-xl">
                <p className="text-sm text-gray-500 mb-1">Keluhan / Problem</p>
                <p className="text-gray-900">{booking.problemDescription}</p>
              </div>
              {booking.customerNote && (
                <div className="col-span-2 bg-amber-50 p-4 rounded-xl">
                  <p className="text-sm text-amber-600 mb-1">Catatan Konsumen</p>
                  <p className="text-amber-900">{booking.customerNote}</p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="border-b border-gray-100 pb-4">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Clock className="h-5 w-5 text-gray-400" /> Riwayat Status
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4">
              <StatusHistoryTimeline history={booking.history} />
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader className="border-b border-gray-100 pb-4">
              <CardTitle className="text-lg">Update Status</CardTitle>
            </CardHeader>
            <CardContent className="pt-4 space-y-4">
              <Select 
                value={booking.status} 
                onChange={(e) => updateStatus(e.target.value)}
              >
                {statuses.map(s => <option key={s} value={s}>{s}</option>)}
              </Select>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="border-b border-gray-100 pb-4">
              <CardTitle className="flex items-center gap-2 text-lg">
                <User className="h-5 w-5 text-gray-400" /> Konsumen
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4 space-y-4">
              <div>
                <p className="text-sm font-medium text-gray-900">{booking.customerName}</p>
                <p className="text-sm text-gray-500">{booking.customerPhone}</p>
              </div>
              
              <div className="space-y-2 pt-2 border-t border-gray-100">
                <Button 
                  variant="outline" 
                  className="w-full justify-start text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50"
                  onClick={() => handleWA("chat")}
                >
                  <MessageCircle className="mr-2 h-4 w-4" /> Chat Bebas
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start text-gray-600"
                  onClick={() => handleWA("confirm")}
                >
                  Kirim Konfirmasi
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start text-gray-600"
                  onClick={() => handleWA("reminder")}
                >
                  Kirim Reminder H-1
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start text-gray-600"
                  onClick={() => handleWA("invoice")}
                >
                  Kirim Estimasi Harga
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start text-gray-600"
                  onClick={() => handleWA("done")}
                >
                  Kirim Info Selesai
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="border-b border-gray-100 pb-4">
              <CardTitle className="flex items-center gap-2 text-lg">
                <FileText className="h-5 w-5 text-gray-400" /> Teknisi
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4 space-y-4">
              <div>
                <label className="text-sm text-gray-500 mb-2 block">Pilih Teknisi</label>
                <Select value={booking.technicianId || ""} onChange={e => updateTechnician(e.target.value)}>
                  <option value="">Belum ditentukan</option>
                  {technicians.map(t => (
                    <option key={t.id} value={t.id}>{t.name}</option>
                  ))}
                </Select>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
