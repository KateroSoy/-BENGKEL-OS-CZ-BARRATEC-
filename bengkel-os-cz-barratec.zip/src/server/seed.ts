import { db } from "../db";
import { services, technicians, bookings, workshopSettings, users, bookingStatusHistory } from "../db/schema";
import { count } from "drizzle-orm";
import crypto from "crypto";
import { format, subDays, addDays } from "date-fns";

export async function seedDatabase() {
  const serviceCount = await db.select({ count: count() }).from(services);
  if (serviceCount[0].count > 0) return; // Already seeded

  console.log("Seeding mock data for demo...");

  // Seed Settings
  await db.insert(workshopSettings).values({
    id: crypto.randomUUID(),
    workshopName: "BENGKEL OS Demo",
    phone: "08123456789",
    address: "Jl. Otomotif No. 1, Jakarta",
    openTime: "08:00",
    closeTime: "17:00",
    maxBookingPerSlot: 3,
    slotIntervalMinutes: 60,
  });

  // Seed Services
  const mockServices = [
    { id: crypto.randomUUID(), name: "Servis Ringan", estimatedDuration: 60, estimatedPrice: 350000 },
    { id: crypto.randomUUID(), name: "Servis Besar", estimatedDuration: 180, estimatedPrice: 1500000 },
    { id: crypto.randomUUID(), name: "Ganti Oli", estimatedDuration: 30, estimatedPrice: 250000 },
    { id: crypto.randomUUID(), name: "Tune Up", estimatedDuration: 90, estimatedPrice: 450000 },
    { id: crypto.randomUUID(), name: "AC Mobil", estimatedDuration: 120, estimatedPrice: 500000 },
  ];
  await db.insert(services).values(mockServices);

  // Seed Technicians
  const mockTechs = [
    { id: crypto.randomUUID(), name: "Budi (Mesin)", specialty: "Mesin" },
    { id: crypto.randomUUID(), name: "Agus (AC & Kelistrikan)", specialty: "AC" },
    { id: crypto.randomUUID(), name: "Joko (Kaki-kaki)", specialty: "Kaki-kaki" },
  ];
  await db.insert(technicians).values(mockTechs);

  // Seed Users
  const adminId = crypto.randomUUID();
  await db.insert(users).values({
    id: adminId,
    name: "Admin Pusat",
    email: "admin@bengkel.com",
    passwordHash: "admin123" // MVP mock
  });

  // Seed Bookings
  const statuses = ["Selesai", "Selesai", "Batal", "Selesai", "Baru", "Menunggu Konfirmasi", "Datang"];
  const names = ["Andi", "Siti", "Bowo", "Rina", "Dodi", "Joko", "Rudi", "Bima"];
  const cars = ["Avanza", "Xenia", "Innova", "Brio", "HR-V", "Fortuner", "Pajero", "Civic"];
  
  const mockBookings = [];
  const mockHistory = [];
  const today = new Date();
  
  // Guarantee at least 5 bookings for today
  const generateBooking = (dateObj: Date) => {
    const bookingDate = format(dateObj, "yyyy-MM-dd");
    const service = mockServices[Math.floor(Math.random() * mockServices.length)];
    const status = statuses[Math.floor(Math.random() * statuses.length)];
    const isCompleted = status === "Selesai";
    const id = crypto.randomUUID();

    mockBookings.push({
      id,
      bookingCode: `BK-${format(new Date(bookingDate), "yyMMdd")}-${crypto.randomBytes(2).toString("hex").toUpperCase()}`,
      customerName: names[Math.floor(Math.random() * names.length)],
      customerPhone: `081${Math.floor(Math.random() * 1000000000)}`,
      bookingDate,
      bookingTime: `${String(Math.floor(Math.random() * 8) + 8).padStart(2, '0')}:00`,
      carType: cars[Math.floor(Math.random() * cars.length)],
      plateNumber: `B ${Math.floor(Math.random() * 9000) + 1000} XYZ`,
      problemDescription: "Servis rutin dan pengecekan",
      serviceType: service.name,
      status: status,
      source: "Online Form",
      estimatedPrice: isCompleted ? service.estimatedPrice : null,
      technicianId: isCompleted ? mockTechs[Math.floor(Math.random() * mockTechs.length)].id : null,
    });

    // Initial status
    mockHistory.push({
      id: crypto.randomUUID(),
      bookingId: id,
      newStatus: "Baru",
      note: "Booking created via online form",
      changedBy: null,
      changedAt: subDays(dateObj, 2)
    });

    // Add status history based on current status
    if (status !== "Baru") {
      mockHistory.push({
        id: crypto.randomUUID(),
        bookingId: id,
        oldStatus: "Baru",
        newStatus: "Menunggu Konfirmasi",
        note: "Admin telah mengecek jadwal",
        changedBy: adminId,
        changedAt: subDays(dateObj, 1)
      });
    }

    if (isCompleted || status === "Datang" || status === "Selesai") {
       mockHistory.push({
        id: crypto.randomUUID(),
        bookingId: id,
        oldStatus: "Menunggu Konfirmasi",
        newStatus: "Datang",
        note: "Konsumen tiba di bengkel",
        changedBy: adminId,
        changedAt: dateObj
      });
    }

    if (isCompleted) {
       mockHistory.push({
        id: crypto.randomUUID(),
        bookingId: id,
        oldStatus: "Datang",
        newStatus: "Selesai",
        note: "Pengerjaan selesai",
        changedBy: adminId,
        changedAt: dateObj
      });
    }
  };

  // Add 5 today
  for (let i = 0; i < 5; i++) {
    generateBooking(today);
  }

  // Add 25 random days
  for (let i = 0; i < 25; i++) {
    generateBooking(addDays(today, Math.floor(Math.random() * 14) - 7));
  }

  await db.insert(bookings).values(mockBookings);
  
  // Insert history in chunks or all at once
  await db.insert(bookingStatusHistory).values(mockHistory);

  console.log("Mock data seeded successfully.");
}
